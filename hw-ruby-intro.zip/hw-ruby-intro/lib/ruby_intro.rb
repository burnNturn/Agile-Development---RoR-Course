

# When done, submit this entire file to the autograder.

# Part 1

def sum arr
  arr.inject(0,:+)
end

def max_2_sum arr
  sum(arr.sort.reverse[0..1])
end

def sum_to_n? arr, n
  for i in arr
    for j in arr
      if i != j
        if i + j == n
          return true
        end
      end
    end
  end
  false
end

# Part 2

def hello(name)
  "Hello, #{name}"
end

def starts_with_consonant? s
  if s.empty?  || !(s[0]).match("[A-Za-z]")
    return false
  end
  !["a", "e", "i", "o", "u"].include?(s[0].downcase)
end

def binary_multiple_of_4? s
  if s.empty?
    false
  elsif (s.match("^([0-1]*)$") != nil)
    s.to_i % 4 == 0
  else
    false
  end
end

#Part 3

class BookInStock

  def initialize (isbn, price)
    raise ArgumentError unless !isbn.empty?
    raise ArgumentError unless price > 0.00
    @isbn = isbn
    @price = price
  end
  
  def isbn
    @isbn
  end
  
  def price
    @price
  end
  
  def isbn=(isbn)
    @isbn = isbn
  end
  
  def price=(price)
    @price = price
  end
  
  def price_as_string 
  "$" + "#{'%.2f' % @price}"
  end
  
end